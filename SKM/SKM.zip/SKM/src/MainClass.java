public class MainClass {
   static Menu m1 = new Menu();
  static Add_Ons a1 = new Add_Ons();
    public static void main(String[] args){
       m1.printMenu();

    }
}
