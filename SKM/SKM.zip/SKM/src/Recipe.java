//Recipe's for all of the smoothies, where add-ons and take-aways are most affected
public class Recipe extends Menu {
}
